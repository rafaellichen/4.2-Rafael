import React from 'react';
import { render } from 'react-dom';

const Select = props => {
//const Select = ({ name, value }) => {
  //let { name, value } = props;
  //let name = props.name;
  //let value = props.value;
  return (
    <select name={props.name} value={props.value} onChange={props.handler}>
    <option value="_">_</option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>

    </select>
  )
}

class App extends React.Component {
  constructor() {
    super();
    this.selectThingies = ['state','components','routes'];
    this.routerPracticeUrl = 'https://github.com/C4Q/AC_4_Web/blob/master/units/react/projects/react_router_1/react_router_1.md';
    this.statePracticeUrl = '';
    this.componentPracticeUrl = '';
    this.state = {
      routes: '_',
      components: '_',
      state: '_'
    };
  }
  handleChange = e => {
    this.setState({
      [e.target.name]: e.target.value
    })
  }
  render() {
    let weakness = undefined;
    let practiceUrl = undefined;
    let {routes, components, state} = this.state;
    if (routes === '_' || components === '_' || state === '_') {
      weakness = 'FINISH THE SURVEY';
      practiceUrl = 'FINISH THE SURVEY';
    } else if (state < components && state < routes) {
      weakness = 'STATE';
      practiceUrl = this.statePracticeUrl;
    } else if (components < state && components < routes) {
      weakness = 'COMPONENTS';
      practiceUrl = this.componentPracticeUrl;
    } else if (routes < state && routes < components) {
      weakness = 'ROUTES';
      practiceUrl = this.routerPracticeUrl;
    } else {
      weakness = 'INDECISIVENESS';
      practiceUrl = 'Eat some pizza';
    }
    return (
        <div>
        <h1>How good are you with..?</h1>
        <h3>Components?</h3>
        <Select name="components" value={this.state.components} handler={this.handleChange} />
        <h3>State</h3>
        <Select name="state" value={this.state.state} handler={this.handleChange} />
        <h3>Routes</h3>
        <Select name="routes" value={this.state.routes} handler={this.handleChange} />
        <p>
        Your weakness is {weakness} and you should practice this: {practiceUrl}.
        </p>
        </div>
      )
    }
}
render(<App />, document.getElementById('root'));
