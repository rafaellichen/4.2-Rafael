import React from "react";
import "./Styles.css"

var thislist=[]

function additem() {
  if(document.getElementById("item").value) {
    thislist.push(document.getElementById("item").value)
    var temp = ""
    thislist.forEach(e => {
      temp += "<li>" + e + "</li>"
    })
    document.getElementById("jokelist").innerHTML = temp
    document.getElementById("item").value = ""
    localStorage.setItem('allitems', thislist);
  }
}

const Joke = () => (
  <div>
    <h1>All Jokes</h1>
    <input id="item" type="text" name="name" />
    <button onClick={additem}>Submit</button>
    <ul id="jokelist">
      {thislist.map(cur => {
        return (<li>{cur}</li>)
      })}
    </ul>
  </div>
);

export default Joke;
