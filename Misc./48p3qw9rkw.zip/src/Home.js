import React from "react";
import "./Styles.css"

const Home = () => (
  <div>
    <h1>Joke Central</h1>
  </div>
);

export default Home;
