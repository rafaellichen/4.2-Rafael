import React from "react";
import { Link, Switch, Route } from "react-router-dom";

import Home from "./Home";
import Joke from "./Joke";
import Random from "./Random"
import "./Styles.css"

const App = () => (
  <div>
    <nav>
      <Link to="/">Joke Central</Link>
      {" "}
      <Link to="/jokes">All Jokes</Link>
      {" "}
      <Link to="/jokes/random">Random Joke</Link>
    </nav>
    <Switch>
      <Route exact path="/" component={Home}/>
      <Route exact path="/jokes/random" component={Random} />
      <Route path="/jokes" component={Joke}/>
    </Switch>
  </div>
);

export default App;
