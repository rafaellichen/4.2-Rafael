import React from "react";
import "./Styles.css"

function randjoke() {
  var temp = localStorage.getItem("allitems").split(",")
  console.log(temp)
  var final = temp[Math.floor(Math.random() * temp.length)];
  document.getElementById("curjoke").innerText= final
}

const Random = () => (
  <div>
    <h1>Random Joke</h1>
    <button onClick={randjoke}>Another Joke</button>
    <p id="curjoke"></p>
  </div>
);

export default Random;
