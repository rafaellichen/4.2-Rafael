import React from "react";

const Home = () => (
  <div>
    <h1>MOVIES MOVIES MOVIES</h1>
  </div>
);

export default Home;
