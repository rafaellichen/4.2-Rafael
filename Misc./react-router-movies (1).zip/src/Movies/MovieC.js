import React from "react";
import { Link } from "react-router-dom";

const MovieC = ({ name, genre, opinion, onChange, rating, id }) => (
  <div>
    <div>
      <h1>{name}</h1>
      <h2> Genre: {genre}</h2>
      <h2> Opinion: {opinion}</h2>
      <h2> Rating: {" "}
        <select onChange={onChange} value={rating} name={id}>
          <option value=" "> </option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
        </select>
      </h2>
      <br/>

      <Link to="/movies">Back</Link>
    </div>
  </div>
);

export default MovieC;
