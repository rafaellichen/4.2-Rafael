// Import libraries
import React from "react";
import { Route, Switch } from "react-router-dom";
// Import the mock API
import moviesAPI from "./moviesAPI";
// Import React Components
import MovieC from "./MovieC";
import MovieListC from "./MovieListC";

class Pets extends React.Component {
  constructor() {
    super()
    this.state = {
    }
  }
  handleRatingSelect = e => {
    this.setState({
      [e.target.name]: e.target.value
    })
  }
  renderPet = props => {
    const { id } = props.match.params;
    let rating = this.state[id];
    if (!rating) { rating = ''; }

    const movie = moviesAPI.getOne(id);
    if (!movie) {
      return <div> could not find movie </div>;
    } else {
      return (
        <MovieC
          name={movie.name}
          genre={movie.genre}
          opinion={movie.opinion}
          rating={rating}
          id={id}
          onChange={this.handleRatingSelect}
        />
      )
    }
  };

  renderPetList = () => {
    const pets = moviesAPI.getAll();
    return <MovieListC pets={pets} />;
  };

  render() {
    return (
      <div>
        <Switch>
          <Route exact path="/movies" render={this.renderPetList} />
          <Route path="/movies/:id" render={this.renderPet} />
        </Switch>
      </div>
    );
  }
}
export default Pets;
