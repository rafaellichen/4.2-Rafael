npm install in /db
npm install in /client
npm start in /client
node index.js