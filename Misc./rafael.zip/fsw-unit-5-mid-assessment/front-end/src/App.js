import React, { Component } from 'react';
import { Link, Switch, Route } from 'react-router-dom';
import "./App.css"

class Submit extends Component {
  render() {
    return (
      <div>
        <input id="userInput" type="text"></input>
        <select id="type">
          <option value="cat">Cat</option>
          <option value="dog">Dog</option>
        </select>
        <button onClick={submiturls}>Submit</button>
      </div>
    );
  }
}

function submiturls() {
  console.log(document.getElementById("type").value)
  console.log(document.getElementById("userInput").value)
  if(document.getElementById("type").value=="cat") {
    fetch("http://localhost:3100/newcat/"+encodeURIComponent(document.getElementById("userInput").value))
    document.getElementById("userInput").value=""
  } else {
    fetch("http://localhost:3100/newdog/"+encodeURIComponent(document.getElementById("userInput").value))
    document.getElementById("userInput").value=""
  }
}

class Home extends Component {
  render() {
    return (
      <div>
        <h1>PET PHOTO PAGE</h1>
      </div>
    )
  }
}

class Dog extends Component {
  constructor() {
    super();
    this.state = {
      urls4dog:[]
    }
  }
  componentDidMount = () => {
    fetch('http://localhost:3100/alldogs')
    .then(response => response.json())
    .then(obj => {
      this.setState({
        urls4dog: obj
      })
    })
  }
  render() {
    const {urls4dog} = this.state;
    return (
      <div>
        {urls4dog.map(img => <img src={img}></img>)}
      </div>
    )
  }
}

class Cat extends Component {
  constructor() {
    super();
    this.state = {
      urls4cat:[]
    }
  }
  componentDidMount = () => {
    fetch('http://localhost:3100/allcats')
    .then(response => response.json())
    .then(obj => {
      this.setState({
        urls4cat: obj
      })
    })
  }
  render() {
    const {urls4cat} = this.state;
    return (
      <div>
        {urls4cat.map(img => <img src={img}></img>)}
      </div>
    )
  }
}

class App extends Component {
  render() {
    return (
      <div>
      <Link to='/'>HOME</Link>{" - "}
      <Link to='/cats'>All Cats</Link>{" - "}
      <Link to='/dogs'>All Dogs</Link>{" - "}
      <Link to='/submit'>SUBMIT</Link>
      <Switch>
        <Route exact path="/cats" component={Cat}/>
        <Route exact path="/dogs" component={Dog}/>
        <Route exact path="/submit" component={Submit}/>
        <Route path="/" component={Home}/>
      </Switch>
      </div>

    );
  }
}

export default App;