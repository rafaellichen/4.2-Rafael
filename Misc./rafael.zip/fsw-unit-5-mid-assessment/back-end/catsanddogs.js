module.exports = {
  cats: [
  'https://www.pets4homes.co.uk/images/articles/3529/large/the-5-best-cat-breeds-for-an-indoor-only-home-5710f19bcc4b2.jpg',
  'https://i.ytimg.com/vi/YKaOXidtXH4/maxresdefault.jpg',
  'https://toypetreviews.com/wp-content/uploads/2017/06/8-best-cat-toilet-training-kits-featured-image.jpg',
  ],
  dogs: [
  'https://listosaur.com/wp-content/uploads/2013/01/killer_chihuahua.jpg',
  'https://www.cheatsheet.com/wp-content/uploads/2017/05/GettyImages-114304972-640x427.jpg',
  'http://www.awesomelycute.com/gallery/2014/07/awesomelycute-com-3977-326x235.jpg',
  ],
}
