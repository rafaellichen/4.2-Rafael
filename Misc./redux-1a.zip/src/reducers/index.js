import count from "./count";

import { combineReducers } from "redux";

export default combineReducers({ count });
