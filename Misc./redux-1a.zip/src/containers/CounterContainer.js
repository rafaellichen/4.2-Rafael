import React from "react";
import { connect } from "react-redux";
import Counter from "../components/Counter";

class CounterContainer extends React.Component {
  increment = () => {
    const { dispatch } = this.props;
    dispatch({ type: "INCREMENT" });
  };

  decrement = () => {
    const { dispatch } = this.props;
    dispatch({ type: "DECREMENT" });
  };

  incrementIfEven = () => {
    const { count } = this.props;
    if(count % 2 === 0){
      this.increment();
    }
  }

  incrementIfOdd = () => {
    const { count } = this.props;
    if (count % 2 === 1) {
      this.increment();
    }
  }

  render() {
    const { count } = this.props;
    console.log(this.props)

    return (
      <Counter
        value={count}
        onIncrement={this.increment}
        onDecrement={this.decrement}
        incrementIfEven={this.incrementIfEven}
        incrementIfOdd={this.incrementIfOdd}
      />

    );
  }
}

// The component is connected to the redux store
export default connect(state => state)(CounterContainer);
