import React from "react";

const Counter = ({ value, onIncrement, onDecrement, incrementIfEven, incrementIfOdd }) => (
  <div>
    <p>value: {value}</p>
    <p>
      <button onClick={onIncrement}>+</button>
      <button onClick={onDecrement}>-</button>
      <button onClick={incrementIfEven}>Increment if Even</button>
      <button onClick={incrementIfOdd}>Increment if Odd</button>
      <button onClick={onDecrement}>Increment Async</button>
    
    </p>
  </div>
);

export default Counter;
