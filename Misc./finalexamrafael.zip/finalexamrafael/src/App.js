import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
import {Link, Switch, Route} from 'react-router-dom'

class AllCards extends Component {
  componentDidMount() {
    const deckID=localStorage.getItem("deckID")
    document.getElementById("deckID").innerHTML = deckID
    fetch("https://deckofcardsapi.com/api/deck/"+deckID+"/pile/rafael/list/")
    .then(response => response.json())
    .then(obj => {
      // console.log(obj)
      var card
      var all=[]
      for (card in obj.piles.rafael.cards) {
        all.push(obj.piles.rafael.cards[card].images.png)
      }
      var temp=""
      for(var i=0; i<all.length; i++) {
        temp+='<img height="153" width="110" src='+all[i]+'></img>'
      }
      // console.log(temp)
      document.getElementById("images").innerHTML=temp
    })
  }
  render() {
    return (
      <div>
        <button id="refresh"onClick={fetchNewDeck}>New deck</button>
        <br/>
        <br/>
        <label id="deckID"></label>
        <br/>
        <br/>
        <div id="images"></div>
      </div>
    )
  }
}

class ShuffleCards extends Component {
  componentDidMount() {
    const deckID=localStorage.getItem("deckID")
    fetch("https://deckofcardsapi.com/api/deck/"+localStorage.getItem("deckID")+"/pile/rafael/shuffle/")
    fetch("https://deckofcardsapi.com/api/deck/"+deckID+"/pile/rafael/list/")
    .then(response => response.json())
    .then(obj => {
      // console.log(obj)
      var card
      var all=[]
      for (card in obj.piles.rafael.cards) {
        all.push(obj.piles.rafael.cards[card].images.png)
      }
      var temp=""
      for(var i=0; i<all.length; i++) {
        temp+='<img height="153" width="110" src='+all[i]+'></img>'
      }
      // console.log(temp)
      document.getElementById("images").innerHTML=temp
    })
  }
  render() {
    return (
      <div>
        <button id="shuffle" onClick={shuffleAll}>Shuffle</button>
        <br/>
        <br/>
        <div id="images"></div>
      </div>
    )
  }
}

class DrawCards extends Component {
  componentDidMount() {
    fetch("https://deckofcardsapi.com/api/deck/"+localStorage.getItem("deckID")+"/pile/rafael/draw/")
    .then(response => response.json())
    .then(obj => {
      if(obj.success) {
        document.getElementById("draw2").src = document.getElementById("draw1").src
        document.getElementById("draw1").src = obj.cards[0].images.png
      } else {
        document.getElementById("draw1").disabled=true
      }
    })
  }
  render() {
    return (
      <div>
        <button id="drawOne" onClick={DrawOne}>Draw a card</button>
        <br/>
        <br/>
        <img id="draw1" height="153" width="110" src="" alt=""></img>
        <img id="draw2" height="153" width="110" src="" alt=""></img>
      </div>
    )
  }
}

function DrawOne() {
  fetch("https://deckofcardsapi.com/api/deck/"+localStorage.getItem("deckID")+"/pile/rafael/draw/")
  .then(response => response.json())
  .then(obj => {
    if(obj.success) {
      document.getElementById("draw2").src = document.getElementById("draw1").src
      document.getElementById("draw1").src = obj.cards[0].images.png
    } else {
      document.getElementById("drawOne").disabled=true
    }
  })
}

function DrawMany() {
  var url = window.location.href.split("/")
  if(url[url.length-1]!==":num") {
    fetch("https://deckofcardsapi.com/api/deck/"+localStorage.getItem("deckID")+"/pile/rafael/draw/?count="+url[url.length-1])
    .then(response => response.json())
    .then(obj => {
      console.log(obj)
      var card
      var all=[]
      for (card in obj.cards) {
        all.push(obj.cards[card].images.png)
      }
      var temp=""
      for(var i=0; i<all.length; i++) {
        temp+='<img height="153" width="110" src='+all[i]+'></img>'
      }
      document.getElementById("manycards").innerHTML=temp
    })
  }
}

class DrawCardsNum extends Component {
  componentDidMount() {
    DrawMany()
  }
  render() {
    return (
      <div>
        <button id="drawmany" onClick={DrawMany}>Draw cards</button>
        <br/>
        <div id="manycards"></div>
      </div>
    )
  }
}

function shuffleAll() {
  document.getElementById("shuffle").disabled=true
  fetch("https://deckofcardsapi.com/api/deck/"+localStorage.getItem("deckID")+"/pile/rafael/shuffle/")
  window.location.reload();
}

function fetchNewDeck() {
  document.getElementById("refresh").disabled=true
  fetch("https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1")
  .then(response => response.json())
  .then(obj => {
    localStorage.setItem("deckID", obj.deck_id)
    document.getElementById("deckID").innerHTML=obj.deck_id
    // console.log(localStorage.getItem("deckID"))
  })
  setTimeout(function() {
    fetch("https://deckofcardsapi.com/api/deck/"+localStorage.getItem("deckID")+"/draw/?count=52")
    .then(response => response.json())
    .then(obj => {
      var card
      var all=[]
      for (card in obj.cards) {
        all.push(obj.cards[card].code)
      }
      setTimeout(function() { 
        fetch("https://deckofcardsapi.com/api/deck/"+localStorage.getItem("deckID")+"/pile/rafael/add/?cards="+all.join(","))
        .then(response => response.json())
        .then(obj => {
          // console.log(obj)
          if(obj.remaining===52) fetchNewDeck()
          else window.location.reload();
        })
      }, 200); 
    })
  }, 200);
}

class App extends Component {
  render() {
    return (
      <div className="App">
        <Link to="/cards">All Cards</Link>{" "}
        <Link to="/cards/shuffle">Shuffle</Link>{" "}
        <Link to="/cards/draw">Draw 1</Link>{" "}
        <Link to="/cards/draw/:num">Draw ?</Link>
        <h1>Deck of Cards</h1>
        <Switch>
          <Route exact path="/cards" component={AllCards}/>
          <Route exact path="/cards/shuffle" component={ShuffleCards}/>
          <Route exact path="/cards/draw" component={DrawCards}/>
          <Route exact path="/cards/draw/:num" component={DrawCardsNum}/>
        </Switch>
      </div>
    );
  }
}

export default App;